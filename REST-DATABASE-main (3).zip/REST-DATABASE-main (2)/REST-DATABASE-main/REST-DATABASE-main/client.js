//REST frontend - HTML kliens, az API elérésére és az adatbázis műveletekre

const apiUrl = 'http://localhost:3000/api/users';
const usersData = document.getElementById('usersData');

//Az API elérése és az adatok lekérése

async function getUsers() {
    try  {
        const response = await fetch(apiUrl); //Kapcsolódás az API-hoz
        const users = await response.json();
        usersData.innerHTML = users.map(user  => `
            <tr>
                <td>${user.id}</td>
                <td>${user.firstName}</td>
                <td>${user.lastName}</td>
                <td>${user.city}</td>
                <td>${user.address}</td>
                <td>${user.phone}</td>
                <td>${user.email}</td>
                <td>${user.gender}</td>
                <td>
                    <button>Törlés</button>
                </td>
            </tr>
            `).join('');
    }
    catch (e) {
        console.error(e.message);
        alert('Hiba történt az adatok elérése során')

    }
}

document.getElementById('userForm').addEventListener('submit', async (e) => {
e.preventDefault();

try {
    const formData = newformData(e.target);
    const data = Object.fromEntries(formData);
      
    if (!data.firstName || !data.lastName || !data.city || !data.address || !data.phone || !data.email || !data.gender){
        alert('Kérem töltse ki az összes mezőt!');
    }
else {
    const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    const result = await response.json();
    if (response.ok) {
        alert('Adatok sikeresen rögzítve!');
        getUsers();
    }
    else {
        alert(result.error);
    }
    e.target.reset();
    
}
}
catch (e) {
    alert(error.message);
}
}); 






getUsers();// Az adatok lekérése szolgáló

