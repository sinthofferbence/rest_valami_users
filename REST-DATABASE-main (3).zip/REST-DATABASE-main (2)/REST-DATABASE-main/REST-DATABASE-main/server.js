const express = require('express');
const sqlite = require('sqlite3').verbose();//hibakeresés
const cors = require('cors');
const app= express();
const port= 3000;

app.use(express.json());
app.use(cors());

//az adatbázis 
const db = new sqlite.Database('users.db', (err) =>{
    if(err) {
        console.log(err.message);
    }
    else {
        console.log('Az adatbázis kapcsolat létrejött.')
    }
})
//adatbázis séma létrehozása
db.run(`CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    gender TEXT NOT NULL 
    )`);
//POST végpont az adatok mentésére a users táblában 
app.post('/api/users',(req,res) =>{
    //adatok elérése
    const {firstName, lastName, city, address, phone, email, gender}= req.body;

    const sql = 'INSERT INTO users (firstName, lastName, city, address, phone, email, gender) VALUES(?,?,?,?,?,?,?)'
    db.run(sql, [firstName, lastName, city, address, phone, email, gender],
    function(err){
        if (err) {
            console.log(err);
            return res.status(500).json({error: "Hiba történt"});
        }
        else {
            res.status(200).send({message: 'Adatok sikeresen rögzítése', id: this.lastID,firstName, lastName, city, address, phone, email, gender});
        }
    })
})

//
app.get('/api/users', (req,res) =>{
   db.all(`SELECT * FROM users`, [], (err, records) =>{
    if(err) {
        console.error(err)
        return res.status(500).json({message: "Hiba történt"});
    }
    else {
        return res.status(200).json(records);
    }
   })
})

app.delete('/api/users/:id', (req,res) =>{
//AZ ID elérése az url paraméterből
const{id} = req.params;

db.run(`DELETE FROM users WHERE id = ?`, [id],
// callback függvény az esetleges törlési hibak kezelésére
function(err){
    if(err) {
        return res.status(500).send(err.message)
    }
    else {
        return res.status(200).json({message: 'Felhasználó sikeresen törölve'})
    }
})
})
//PUT BÉGPONT A TÁBLÁBAN 
app.put('/api/users/:id', (req,res) =>{
    const {id} = req.params;
    const {firstName, lastName, city, address, phone, email, gender} = req.body;
    const sql = `UPDATE users SET firstName = ?, lastName = ?, city = ?, address = ?, phone = ?, email  = ?, gender = ? WHERE id = ?`;
    db.run(sql, [firstName, lastName, city, address, phone, email, gender, id],
     function(err){
    if(err) {
        return res.status(500).send(err.message)
    }
    else {
        return res.status(200).json({message: 'Felhasználó sikeresen fRISSÍTVE', id, firstName, lastName, city, address, phone, email, gender});
    }
        }
    )
})




    app.listen(port, () => {
        console.log(`A szerver fut a http://localhost: ${port} címen`);
    })
